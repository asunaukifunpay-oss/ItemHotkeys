package ru.example.itemhotkeys;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;
import java.util.function.Predicate;

public final class ItemHotkeysClient implements ClientModInitializer {
    private static final String CATEGORY = "category.itemhotkeys.binds";

    private static KeyBinding enderTrapKey;
    private static KeyBinding trapKey;
    private static KeyBinding livalkaKey;
    private static KeyBinding antiFlyKey;

    private static PendingAction pendingAction;

    @Override
    public void onInitializeClient() {
        enderTrapKey = register("key.itemhotkeys.ender_trap", GLFW.GLFW_KEY_Z);
        trapKey = register("key.itemhotkeys.trap", GLFW.GLFW_KEY_X);
        livalkaKey = register("key.itemhotkeys.livalka", GLFW.GLFW_KEY_C);
        antiFlyKey = register("key.itemhotkeys.antifly", GLFW.GLFW_KEY_V);

        ClientTickEvents.END_CLIENT_TICK.register(ItemHotkeysClient::onEndTick);
    }

    private static KeyBinding register(String translationKey, int defaultKey) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                translationKey,
                InputUtil.Type.KEYSYM,
                defaultKey,
                CATEGORY
        ));
    }

    private static void onEndTick(MinecraftClient client) {
        tickPending(client);

        if (!canAct(client) || pendingAction != null) {
            drainKeys();
            return;
        }

        while (enderTrapKey.wasPressed()) {
            useNamedItem(client, exactName("Эндер Ловушка"), "Эндер Ловушка", false);
        }
        while (trapKey.wasPressed()) {
            useNamedItem(client, exactName("Ловушка"), "Ловушка", false);
        }
        while (livalkaKey.wasPressed()) {
            useNamedItem(client, exactName("Ливалка"), "Ливалка", false);
        }
        while (antiFlyKey.wasPressed()) {
            useNamedItem(client, exactName("Анти-Флай"), "Анти-Флай", true);
        }
    }

    private static void drainKeys() {
        while (enderTrapKey.wasPressed()) { }
        while (trapKey.wasPressed()) { }
        while (livalkaKey.wasPressed()) { }
        while (antiFlyKey.wasPressed()) { }
    }

    private static boolean canAct(MinecraftClient client) {
        return client.player != null
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && client.currentScreen == null;
    }

    private static Predicate<ItemStack> exactName(String wanted) {
        String normalizedWanted = normalize(wanted);
        return stack -> !stack.isEmpty() && normalize(stack.getName().getString()).equals(normalizedWanted);
    }

    private static String normalize(String text) {
        return text.trim()
                .replace('ё', 'е')
                .replace('Ё', 'Е')
                .toLowerCase(Locale.ROOT);
    }

    private static void useNamedItem(
            MinecraftClient client,
            Predicate<ItemStack> matcher,
            String displayName,
            boolean antiFly
    ) {
        int inventoryIndex = findItem(client.player.getInventory(), matcher);
        if (inventoryIndex < 0) {
            client.player.sendMessage(Text.literal("§c[Item Hotkeys] Не найден предмет: " + displayName), true);
            return;
        }

        int selectedHotbar = client.player.getInventory().selectedSlot;
        boolean moved = inventoryIndex != selectedHotbar;

        if (moved) {
            int slotId = inventoryIndexToScreenSlot(inventoryIndex);
            client.interactionManager.clickSlot(
                    client.player.currentScreenHandler.syncId,
                    slotId,
                    selectedHotbar,
                    SlotActionType.SWAP,
                    client.player
            );
        }

        pendingAction = new PendingAction(
                antiFly ? ActionType.ANTI_FLY : ActionType.RIGHT_CLICK,
                moved,
                inventoryIndex,
                selectedHotbar,
                1,
                client.player.isSneaking()
        );
    }

    private static int findItem(PlayerInventory inventory, Predicate<ItemStack> matcher) {
        // Сначала хотбар, затем основная часть инвентаря.
        for (int i = 0; i < 9; i++) {
            if (matcher.test(inventory.getStack(i))) return i;
        }
        for (int i = 9; i < 36; i++) {
            if (matcher.test(inventory.getStack(i))) return i;
        }
        return -1;
    }

    private static int inventoryIndexToScreenSlot(int inventoryIndex) {
        // PlayerScreenHandler: 9..35 совпадают, хотбар 0..8 находится в слотах 36..44.
        return inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
    }

    private static void tickPending(MinecraftClient client) {
        if (pendingAction == null) return;
        if (!canActIgnoringScreen(client)) {
            pendingAction = null;
            return;
        }

        if (pendingAction.delayTicks > 0) {
            pendingAction.delayTicks--;
            return;
        }

        switch (pendingAction.type) {
            case RIGHT_CLICK -> {
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                pendingAction.delayTicks = 2;
                pendingAction.type = ActionType.RESTORE;
            }
            case ANTI_FLY -> {
                if (!pendingAction.wasSneaking) {
                    client.options.sneakKey.setPressed(true);
                    client.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(
                            client.player,
                            ClientCommandC2SPacket.Mode.PRESS_SHIFT_KEY
                    ));
                }
                pendingAction.delayTicks = 2;
                pendingAction.type = ActionType.RELEASE_SNEAK;
            }
            case RELEASE_SNEAK -> {
                if (!pendingAction.wasSneaking) {
                    client.options.sneakKey.setPressed(false);
                    client.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(
                            client.player,
                            ClientCommandC2SPacket.Mode.RELEASE_SHIFT_KEY
                    ));
                }
                pendingAction.delayTicks = 1;
                pendingAction.type = ActionType.RESTORE;
            }
            case RESTORE -> {
                restoreOriginalSlot(client, pendingAction);
                pendingAction = null;
            }
        }
    }

    private static boolean canActIgnoringScreen(MinecraftClient client) {
        return client.player != null
                && client.interactionManager != null
                && client.getNetworkHandler() != null;
    }

    private static void restoreOriginalSlot(MinecraftClient client, PendingAction action) {
        if (!action.moved) return;

        client.interactionManager.clickSlot(
                client.player.currentScreenHandler.syncId,
                inventoryIndexToScreenSlot(action.sourceInventoryIndex),
                action.selectedHotbarSlot,
                SlotActionType.SWAP,
                client.player
        );
    }

    private enum ActionType {
        RIGHT_CLICK,
        ANTI_FLY,
        RELEASE_SNEAK,
        RESTORE
    }

    private static final class PendingAction {
        private ActionType type;
        private final boolean moved;
        private final int sourceInventoryIndex;
        private final int selectedHotbarSlot;
        private int delayTicks;
        private final boolean wasSneaking;

        private PendingAction(
                ActionType type,
                boolean moved,
                int sourceInventoryIndex,
                int selectedHotbarSlot,
                int delayTicks,
                boolean wasSneaking
        ) {
            this.type = type;
            this.moved = moved;
            this.sourceInventoryIndex = sourceInventoryIndex;
            this.selectedHotbarSlot = selectedHotbarSlot;
            this.delayTicks = delayTicks;
            this.wasSneaking = wasSneaking;
        }
    }
}
